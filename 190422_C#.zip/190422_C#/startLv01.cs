﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;


public class startLv01 : MonoBehaviour
{
 
    public void ButtonLv1Click()
    {
        SceneManager.LoadScene("s02_StartLv01");
    }
}
