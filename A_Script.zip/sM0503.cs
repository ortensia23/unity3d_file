﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;


public class sM0503 : MonoBehaviour
{

    public void backBtn()
    {
        SceneManager.LoadScene("s05_Menu3");
    }

    /* public void level01()
     {
         SceneManager.LoadScene("s06_StartLv01");
     }

     */

    public void backBtnCat()
    {
        SceneManager.LoadScene("s05_Menu4");
    }

    public void backBtnSnow()
    {
        SceneManager.LoadScene("s05_Menu2");
    }

    public void exitBtn()
    {

        Application.Quit();
    }

}