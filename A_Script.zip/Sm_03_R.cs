﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using UnityEngine.SceneManagement;

public class Sm7_8 : MonoBehaviour
{
    public void ButtonClick()
    {
        SceneManager.LoadScene("s03_SetRehab");
    }
}


