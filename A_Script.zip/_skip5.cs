﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using UnityEngine.SceneManagement;


public class _skip5 : MonoBehaviour
{


    public void cakeBtnClick()
    {
        SceneManager.LoadScene("s05_Menu");
    }




    /*public void ButtonLogin()
    {

        SceneManager.LoadScene("s01_Menu");
    }
    */


}
