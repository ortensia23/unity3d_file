﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;


public class sM0502 : MonoBehaviour
{

    public void backBtn()
    {
        SceneManager.LoadScene("s04_Content_Select");
    }

   /* public void level01()
    {
        SceneManager.LoadScene("s06_StartLv01");
    }
    */


    public void exitBtn()
    {

        Application.Quit();
    }

}