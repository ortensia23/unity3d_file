﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;


public class sM0301 : MonoBehaviour
{
  

    public void backBtn()
    {
        SceneManager.LoadScene("s03_A_Setting");
    }

    public void exitBtn()
    {

        Application.Quit();
    }

}

 

