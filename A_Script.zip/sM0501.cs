﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;


public class sM0501 : MonoBehaviour
{


    public void backBtn()
    {
        SceneManager.LoadScene("s04_Content_Select");
    }

    public void level01()
    {
        SceneManager.LoadScene("s06_StartLv01");
    }

    public void level02()
    {
        SceneManager.LoadScene("s_snow");
    }

    public void level03()
    {
        SceneManager.LoadScene("s_basketball");
    }

    public void level04()
    {
        SceneManager.LoadScene("s_cat");
    }

    public void basketLevel05()
    {
        SceneManager.LoadScene("game_1");
    }


    public void exitBtn()
    {

        Application.Quit();
    }

}