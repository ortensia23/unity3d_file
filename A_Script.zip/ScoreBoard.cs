﻿/*using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
//using UnityEngine.SceneManagement;
using Leap;

public class ScoreBoard : MonoBehaviour
{

    public static int score =0;

    public Text scoreText;
    public Text highScoreText;

    private int savedScore = 0;


}*/