﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;


public class sM04 : MonoBehaviour
{
  
    public void selectCake()
    {
        SceneManager.LoadScene("s05_Menu");
    }

    public void selectSanta()
    {
        SceneManager.LoadScene("s05_Menu2");
    }

    public void selectBall()
    {
        SceneManager.LoadScene("s05_Menu3");
    }

    public void selectCat()
    {
        SceneManager.LoadScene("s05_Menu4");
    }

    public void backBtn()
    {
        SceneManager.LoadScene("s03_A_Setting");
    }

    public void exitBtn()
    {

        Application.Quit();
    }

}

 

