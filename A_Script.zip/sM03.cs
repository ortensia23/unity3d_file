﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;


public class sM03 : MonoBehaviour
{
  
    public void settingBtn()
    {
        SceneManager.LoadScene("s03_SetRehab");
    }

    public void rehabNowBtn()
    {
        SceneManager.LoadScene("s04_Content_Select");
    }

   /* public void configurationBtn()
    {
        SceneManager.LoadScene("");
    }

   */

    public void backBtn()
    {
        SceneManager.LoadScene("s02_login");
    }

    public void exitBtn()
    {

        Application.Quit();
    }

}

 

