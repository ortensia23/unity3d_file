﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using UnityEngine.SceneManagement;

public class timer : MonoBehaviour
{

    public Text timeText;
    private float time;
    private float realTime = 0f;
    Animator animator;


    void Start()
    {
        //  StartCoroutine(Example());
       
    }

    private void Awake()
    {
        StartCoroutine(Example());
        animator = GetComponent<Animator>();
        //time = 100f;

    }


    private void Update()
    {

        time -= Time.deltaTime;

        if (time > 0f)
        {

            //  timeText.text = Mathf.Ceil(time).ToString();   //반올림
            timeText.text = string.Format("{0:N2}", time);

        }

        if (time <= 0.0f)

        { SceneManager.LoadScene("s04_Level01_score"); }


    }

    IEnumerator Example()
    {

        yield return new WaitForSeconds(5);
        time = 100f;



        //   private int min;




    }

}



