﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using Leap;

public class TrayWood : MonoBehaviour
{
    public static int score = 0;
    public Text scoreText;
    public Text finalScoreText;
    public Text highScoreText;

    private int savedScore = 0;
    private string KeyString = "HighScore";

    Controller controller;



    void OnTriggerEnter(Collider col)
    {
        if (col.gameObject.tag == "Sweets" )
        {
            Destroy(col.gameObject);
            GetScore();

     

        }
    }



    void GetScore()
    {
        score++;
        scoreText.text = score + "개";
    }

    void Awake()
    {
        savedScore = PlayerPrefs.GetInt(KeyString, 0);
        highScoreText.text = "High Score:" + savedScore.ToString("0");
    }

    void Update()
    {
        scoreText.text = "Score:" + score.ToString("0");

        if (score > savedScore) {
            PlayerPrefs.SetInt(KeyString, score);
        }

            }

}
