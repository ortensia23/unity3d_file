﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using UnityEngine.SceneManagement;
using Leap;

public class _skip_ : MonoBehaviour
{

    void Update()
    {
        if(Input.GetMouseButtonDown(0))
        {
        SceneManager.LoadScene("s04_Level01_score");
        
        }
    }


    /*public void ButtonLogin()
    {

        SceneManager.LoadScene("s01_Menu");
    }
    */


}
