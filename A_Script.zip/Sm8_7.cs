﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using UnityEngine.SceneManagement;

public class Sm8_7 : MonoBehaviour
{
    public void Button7Click()
    {
        SceneManager.LoadScene("s07_GameDp");
    }
}


