﻿/*using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class DataInserter : MonoBehaviour
{
    public string inputUserName;
    public string inputPassword;
    public string inputEmail;

    string CreateUserURL = "http://localhost:8080/VR/VRworld.jsp";

    //use this for initialization
    void start()
    {
    }

    //update is called once per frame
    void Updata()
    {
        If(Input.GetKeyDown(KeyCode.space))
        {

            CreateUser(inputUserName, inputPassword, inputEmail);
        }
    }

    public void CreateUser(string username, string password, string email)
    {
        WWWForm form = new WWWForm();
        form.AddField("usernamePost", username);
        form.AddField("PasswordPost", password);
        form.AddField("emailPost", email);

        WWW www = new WWW(CreateUserURL, form);
    }
}*/