﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;


public class s_mainCake : MonoBehaviour
{




    public GameObject finalScoreBoard;



    public void showScoreBtn()
    {
        finalScoreBoard.SetActive(!finalScoreBoard.active); // 한 버튼에 팝업 on/off 기능 모두 들어가 있음.
    }





    public void backBtn()
    {
        SceneManager.LoadScene("s06_StartLv01");
    }




    public void exitBtn()
    {

        Application.Quit();
    }

}


