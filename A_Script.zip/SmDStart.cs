﻿/*using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using UnityEngine.SceneManagement;

public class SmDStart : MonoBehaviour
{
    public void ButtonDClick()
    {
        SceneManager.LoadScene("s09_No.1");
    }
}

*/