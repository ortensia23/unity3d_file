﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;


public class sM0601 : MonoBehaviour
{
  
    
        public void backBtn()
        {
            SceneManager.LoadScene("s05_Menu");
        }

    public void praticeCakeBtn()
    {
        SceneManager.LoadScene("s07_GameDp");
    }

    public void startCake()
    {
        SceneManager.LoadScene("s09_No.1");
    }

  

    public void exitBtn()
    {

        Application.Quit();
    }

 

}
