﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using UnityEngine.SceneManagement;


public class sM10 : MonoBehaviour
{

    void Update()
    {
        if(Input.GetMouseButtonDown(0))
        {
        SceneManager.LoadScene("s09_No.1");
        
        }
    }


    /*public void ButtonLogin()
    {

        SceneManager.LoadScene("s01_Menu");
    }
    */


}
