﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using UnityEngine.SceneManagement;


public class _skip11 : MonoBehaviour
{

    void Update()
    {
        if(Input.GetMouseButtonDown(0))
        {
        SceneManager.LoadScene("s11_GOver");
        
        }
    }


    /*public void ButtonLogin()
    {

        SceneManager.LoadScene("s01_Menu");
    }
    */


}
