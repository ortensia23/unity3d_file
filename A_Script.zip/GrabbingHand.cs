﻿/*using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using Leap;
// Leap Motion hand script that detects pinches and grabs the closest rigidbody.
public class GrabbingHand : MonoBehaviour
{
    public enum PinchState
    {
        kPinched,
        kReleased,
        kReleasing
    }
    // Layers that we can grab.
    public LayerMask grabbableLayers = ~0;
    // Ratio of the length of the proximal bone of the thumb that will trigger a pinch.
    public float grabTriggerDistance = 0.7f;
    // Ratio of the length of the proximal bone of the thumb that will trigger a release.
    public float releaseTriggerDistance = 1.2f;
    // Maximum distance of an object that we can grab when pinching.
    public float grabObjectDistance = 2.0f;
    // If the object gets far from the pinch we'll break the bond.
    public float releaseBreakDistance = 0.3f;
    // Curve of the trailing off of strength as you release the object.
    public AnimationCurve releaseStrengthCurve;
    // Filtering the rotation of grabbed object.
    public float rotationFiltering = 0.4f;
    // Filtering the movement of grabbed object.
    public float positionFiltering = 0.4f;
    // Minimum tracking confidence of the hand that will cause a change of state.
    public float minConfidence = 0.1f;
    // Clamps the movement of the grabbed object.
    public Vector3 maxMovement = new Vector3(Mathf.Infinity, Mathf.Infinity, Mathf.Infinity);
    public Vector3 minMovement = new Vector3(-Mathf.Infinity, -Mathf.Infinity, -Mathf.Infinity);
    protected PinchState pinch_state_;
    protected Collider active_object_;
    protected float last_max_angular_velocity_;
    protected Quaternion rotation_from_palm_;
    protected Vector3 current_pinch_position_;
    protected Vector3 filtered_pinch_position_;
    protected Vector3 object_pinch_offset_;
    protected Quaternion palm_rotation_;
    void Start()
    {
        pinch_state_ = PinchState.kReleased;
        active_object_ = null;
        last_max_angular_velocity_ = 0.0f;
        rotation_from_palm_ = Quaternion.identity;
        current_pinch_position_ = Vector3.zero;
        filtered_pinch_position_ = Vector3.zero;
        object_pinch_offset_ = Vector3.zero;
        palm_rotation_ = Quaternion.identity;
    }
    void OnDestroy()
    {
        OnRelease();
    }
    // Finds the closest grabbable object within range of the pinch.
    protected Collider FindClosestGrabbableObject(Vector3 pinch_position)
    {
        Collider closest = null;
        float closest_sqr_distance = grabObjectDistance * grabObjectDistance;
        Collider[] close_things =
            Physics.OverlapSphere(pinch_position, grabObjectDistance, grabbableLayers);
        for (int j = 0; j < close_things.Length; ++j)
        {
            float sqr_distance = (pinch_position - close_things[j].transform.position).sqrMagnitude;
            if (close_things[j].GetComponent<Rigidbody>() != null && sqr_distance < closest_sqr_distance &&
                !close_things[j].transform.IsChildOf(transform) &&
                close_things[j].tag != "NotGrabbable")
            {
                GrabbableObject grabbable = close_things[j].GetComponent<GrabbableObject>();
                if (grabbable == null || !grabbable.IsGrabbed())
                {
                    closest = close_things[j];
                    closest_sqr_distance = sqr_distance;
                }
            }
        }
        return closest;
    }
    // Notify grabbable objects when they are ready to grab :)
    protected void Hover()
    {
        Collider hover = FindClosestGrabbableObject(current_pinch_position_);
        if (hover != active_object_ && active_object_ != null)
        {
            GrabbableObject old_grabbable = active_object_.GetComponent<GrabbableObject>();
            if (old_grabbable != null)
                old_grabbable.OnStopHover();
        }
        if (hover != null)
        {
            GrabbableObject new_grabbable = hover.GetComponent<GrabbableObject>();
            if (new_grabbable != null)
                new_grabbable.OnStartHover();
        }
        active_object_ = hover;
    }
    protected void StartPinch()
    {
        // Only pinch if we're hovering over an object.
        if (active_object_ == null)
            return HandModel; 
    }
}
       // 


    */