﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;


public class sM08pinch : MonoBehaviour
{

    void Update()
    {
        if (Input.GetMouseButtonDown(0))
        {
            SceneManager.LoadScene("s07_GameDp");

        }
    }


    public void backBtn()
    {
        SceneManager.LoadScene("s07_GameDp");
    }

    public void exitBtn()
    {

        Application.Quit();
    }
 

}

 

