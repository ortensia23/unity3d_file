﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;


public class sM02 : MonoBehaviour
{
  
    public void loginBtn()
    {
        SceneManager.LoadScene("s03_A_Setting");
    }


  /*

    public void backBtn()
    {
        SceneManager.LoadScene("");
    }

    public void exitBtn()
    {

        Application.Quit();
    }
    */

}

 

