﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;


public class GameStart02 : MonoBehaviour
{
 
    public void ButtonLv1Click()
    {
        
        SceneManager.LoadScene("s09_No.2");
    }
}
