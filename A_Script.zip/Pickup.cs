﻿/*using UnityEngine;
using System.Collections;
using System.Collections.Generic;
using Leap.Unity;

public class Pickup : MonoBehaviour
{
    public static Pickup instance;

    public GameObject _target;

    private void Awake()
    {
        instance = this;
    }


    public void setTarget(GameObject target)
    {
        if (_target == null)
        {
            _target = target;

            if (_target.tag == "GrabTarget" && _target.GetComponent<GrabbedEvent>().aleadyGrabbed == true)
            {

            }
            else
            {
                _target.GetComponent<Renderer>().material.color = Color.yellow;

            }
        }
    }

    public void pickupTarget()
    {
        if (_target)
        {
            StartCoroutine(changeParent());
            Rigidbody rb = _target.gameObject.GetComponent<Rigidbody>();
            if (rb != null)
            {
                rb.isKinematic = true;
            }

            _target.GetComponent<Renderer>().material.color = Color.green;
        }
    }


    //Avoids object jumping when passing from hand to hand.
    IEnumerator changeParent()
    {
        yield return null;
        if (_target != null)
            _target.transform.parent = transform;
    }

    public void releaseTarget()
    {
        if (_target && _target.activeInHierarchy)
        {
            if (_target.transform.parent == transform)
            { //Only reset if we are still the parent
                Rigidbody rb = _target.gameObject.GetComponent<Rigidbody>();
                if (rb != null)
                {
                    rb.isKinematic = false;
                }
                _target.transform.parent = null;

                _target.GetComponent<Renderer>().material.color = Color.white;
            }
            _target = null;
        }
    }

    public void clearTarget()
    {
        if (_target != null)
        {
            _target.GetComponent<Renderer>().material.color = Color.white;
        }
        _target = null;
    }

}
*/

