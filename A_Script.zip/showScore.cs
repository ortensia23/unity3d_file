﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
 

public class showScore: MonoBehaviour  // 인포메이션Btn 어느 부위에 좋은 재활동작인지 설명.
{
    public GameObject finalScoreBoard; 

    public void showScoreBtn() 
    {
        finalScoreBoard.SetActive(!finalScoreBoard.active); // 한 버튼에 팝업 on/off 기능 모두 들어가 있음.
    }

}
